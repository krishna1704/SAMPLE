variable "twistlock_namespace" {
  description = "twistlock namespace"
}
variable "twistlock_daemonset_helmchart_name" {
  description = "Twistlock daemonset helm chart name"
}

variable "twistlock_daemonset_helmchart" {
  description = "Twistlock daemonset helm chart"
}

variable "twistlock_helmvalues" {
  description = "Twistlock helm chart values"
}

variable "twistlock_webhook_helmchart_name" {
  description = "Twistlock webhook helm chart name"
}

variable "twistlock_webhook_helmchart" {
  description = "Twistlock webhook helm chart"
}

variable "registry_username" {
  type        = string
  description = "The registry username"
}
variable "registry_secret" {
  type        = string
  description = "The registry secret"
}

variable "registry_server" {
  description = "The registry server"
}

variable "imgpullsecret" {
  description = "Image pull secret name"
}

variable "twistlock_namespace_labels" {
  description = "the twistlock namespace labels"
}

variable "kubernetes_version" {
  description = "The cluster kubernetes version"
}
