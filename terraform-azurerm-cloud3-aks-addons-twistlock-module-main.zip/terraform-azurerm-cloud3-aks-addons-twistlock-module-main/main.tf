resource "kubernetes_namespace" "twistlock_namespace" {
  metadata {
    name = var.twistlock_namespace
    labels = {
	    application = var.twistlock_namespace_labels.application-lbl
      Environment = var.twistlock_namespace_labels.environment-lbl
      ns-contact-name = var.twistlock_namespace_labels.ns-contact-name-lbl
      ns-ad-group-name = var.twistlock_namespace_labels.ns-ad-group-name-lbl
    }
  }
}

resource "kubernetes_secret" "pullsecret" {
  metadata {
    name = var.imgpullsecret
    namespace = var.twistlock_namespace
  }

  data = {
    ".dockerconfigjson" = <<DOCKER
{
  "auths": {
    "${var.registry_server}": {
      "auth": "${base64encode("${var.registry_username}:${var.registry_secret}")}"
    }
  }
}
DOCKER
  }
  type = "kubernetes.io/dockerconfigjson"

  depends_on = [kubernetes_namespace.twistlock_namespace]
}

resource "helm_release" "twistlock_daemonset" {
  name      = var.twistlock_daemonset_helmchart_name
  chart     = var.twistlock_daemonset_helmchart
  namespace = kubernetes_namespace.twistlock_namespace.metadata.0.name

  values = [templatefile(var.twistlock_helmvalues, {imgpullsecret = var.imgpullsecret, registry_server = var.registry_server})]

  set {
    name = "daemonset.defenderType"
    value = substr(var.kubernetes_version, 0, 4) >= 1.19 ? "cri" : "daemonset"
  }

  depends_on = [kubernetes_namespace.twistlock_namespace]
}

resource "helm_release" "twistlock_webhook" {
  name      = var.twistlock_webhook_helmchart_name
  chart     = var.twistlock_webhook_helmchart
  namespace = kubernetes_namespace.twistlock_namespace.metadata.0.name

  values = [file(var.twistlock_helmvalues)]
  depends_on = [helm_release.twistlock_daemonset]
}
